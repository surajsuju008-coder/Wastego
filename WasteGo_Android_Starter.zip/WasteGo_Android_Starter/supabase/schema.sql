-- WasteGo initial database schema
-- Run this in Supabase Dashboard -> SQL Editor.
-- Never put a service_role key in the Android app.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'WasteGo user',
  phone text,
  role text not null default 'customer' check (role in ('customer','admin','employee')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete cascade,
  assigned_to uuid references public.profiles(id) on delete set null,
  waste_type text not null check (waste_type in ('Wet waste','Dry waste','Mixed waste','Bulk waste')),
  frequency text not null check (frequency in ('One-time','Daily','Weekly')),
  address text not null,
  pickup_date date not null,
  time_slot text not null,
  notes text,
  status text not null default 'pending' check (status in ('pending','assigned','collected','cancelled')),
  created_at timestamptz not null default now()
);

-- Create a profile automatically after a successful sign-up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', 'WasteGo user'),
    nullif(new.raw_user_meta_data ->> 'phone', '')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Helper avoids recursive profile-policy checks.
create or replace function public.is_wastego_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.bookings enable row level security;

drop policy if exists "Profiles: user or admin can read" on public.profiles;
create policy "Profiles: user or admin can read"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or public.is_wastego_admin());

drop policy if exists "Bookings: customer creates own" on public.bookings;
create policy "Bookings: customer creates own"
on public.bookings for insert to authenticated
with check (
  customer_id = (select auth.uid())
  and assigned_to is null
  and status = 'pending'
);

drop policy if exists "Bookings: customer employee admin can read" on public.bookings;
create policy "Bookings: customer employee admin can read"
on public.bookings for select to authenticated
using (
  customer_id = (select auth.uid())
  or assigned_to = (select auth.uid())
  or public.is_wastego_admin()
);

drop policy if exists "Bookings: admin updates all" on public.bookings;
create policy "Bookings: admin updates all"
on public.bookings for update to authenticated
using (public.is_wastego_admin())
with check (public.is_wastego_admin());

drop policy if exists "Bookings: assigned employee updates assigned job" on public.bookings;
create policy "Bookings: assigned employee updates assigned job"
on public.bookings for update to authenticated
using (assigned_to = (select auth.uid()))
with check (assigned_to = (select auth.uid()));

grant usage on schema public to authenticated;
grant select on public.profiles to authenticated;
grant select, insert, update on public.bookings to authenticated;

-- IMPORTANT: after creating your own account, promote it to admin manually:
-- update public.profiles set role = 'admin' where id = 'YOUR_AUTH_USER_UUID';
-- To make an employee account, use role = 'employee' instead.
-- Find UUIDs in Authentication -> Users. Never allow public sign-up to choose a role.
