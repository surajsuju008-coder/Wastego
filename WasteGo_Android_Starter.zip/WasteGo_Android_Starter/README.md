# WasteGo Android — beginner starter project

This is the first real cloud-connected Android app foundation for WasteGo.
It includes email/password authentication, customer pickup requests, a cloud booking table,
an admin order view, employee assignment and collection status updates.

## Important before using it with real customers

- This is an MVP starter, not a finished commercial waste service.
- The app does not yet include live GPS, payment collection, push notifications, photo proof,
  recurring automatic booking generation, or a public customer support system.
- Confirm local municipal permissions, authorised waste destinations, worker safety procedures
  and service coverage before accepting real waste collection requests.
- Do not store passwords, Supabase service-role keys, payment secrets or private credentials in
  the app. The app uses only the public Supabase publishable key; database access is protected
  by Row Level Security (RLS).
- Public sign-up always creates a `customer`. Admin/employee roles must be assigned manually
  by the project owner in the Supabase SQL editor.

## Part A — create the Expo project

You need a computer (Windows/Mac/Linux) for the simplest build workflow.
Install Node.js LTS first, then open Terminal / PowerShell and run:

```bash
npx create-expo-app@latest WasteGo --template blank-typescript
```

Copy the files from this starter folder into the newly created `WasteGo` folder,
replacing `App.tsx` and adding `lib/`, `.env.example`, `supabase/`, `app.json` and `eas.json`.

Then run:

```bash
cd WasteGo
npx expo install @supabase/supabase-js react-native-url-polyfill expo-sqlite
```

## Part B — create the cloud database

1. Create a Supabase account and a new project in the Supabase dashboard.
2. Open the project's SQL Editor.
3. Open `supabase/schema.sql` from this project, copy all SQL, paste it into SQL Editor and run it.
4. Open Project Settings / Connect and copy the Project URL and publishable key.
5. Copy `.env.example` to a new file named `.env`.
6. Replace the example values in `.env` with your own URL and publishable key.

Example `.env` (use your own values):

```env
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Never use a `service_role` key in the Android app.

## Part C — run on Android

Install Expo Go from the official Google Play Store on your Android phone.
Keep your computer and phone on the same Wi-Fi network.

From the project folder:

```bash
npx expo start
```

Scan the QR code using Expo Go. If Expo Go reports an SDK compatibility issue,
follow the Expo CLI's suggested version/build instructions.

## Part D — create your first admin and employee accounts

1. Create your own account in the app.
2. In Supabase Dashboard, open Authentication -> Users and copy your account UUID.
3. In SQL Editor, run this command after replacing the UUID:

```sql
update public.profiles
set role = 'admin'
where id = 'YOUR_AUTH_USER_UUID';
```

4. Create a second account through the app for an employee.
5. Copy that employee's UUID and run:

```sql
update public.profiles
set role = 'employee'
where id = 'EMPLOYEE_AUTH_USER_UUID';
```

6. Log out and log back in after changing a role.

The customer app can create bookings. Admins can view all bookings, assign employees and
change booking status. Employees can view assigned jobs and mark them collected.

## Part E — make an installable APK

For an Android installable build, configure EAS:

```bash
npm install --global eas-cli
eas login
eas build:configure
```

The included `eas.json` has an APK preview profile. Start a cloud build:

```bash
eas build --platform android --profile preview
```

When the build finishes, use the build page's install link to download and install the APK.
Cloud builds require an Expo account and may be subject to Expo's current plan limits.

## Troubleshooting

- `Invalid API key`: check that the `.env` uses the Supabase publishable key, not the secret key.
- `relation profiles does not exist`: run `supabase/schema.sql` in the correct Supabase project.
- `new row violates row-level security`: check that SQL ran fully and the user is signed in.
- Profile not created: inspect Supabase Auth logs and confirm the `on_auth_user_created` trigger exists.
- Role screen did not change: sign out and sign back in after editing the profile role.
- App cannot connect: check the Supabase project URL, internet connection and `.env` filename.

## Official documentation

- Expo project setup: https://docs.expo.dev/get-started/create-a-project/
- Expo Android builds: https://docs.expo.dev/build/setup/
- Supabase React Native quickstart: https://supabase.com/docs/guides/auth/quickstarts/react-native
- Supabase Expo quickstart: https://supabase.com/docs/guides/getting-started/quickstarts/expo-react-native
