import 'react-native-url-polyfill/auto';
import 'expo-sqlite/localStorage/install';
import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Platform,
  SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput,
  TouchableOpacity, View
} from 'react-native';
import { supabase } from './lib/supabase';

type Profile = { id: string; full_name: string; phone: string | null; role: 'customer' | 'admin' | 'employee' };
type Booking = {
  id: string; customer_id: string; assigned_to: string | null; waste_type: string;
  frequency: string; address: string; pickup_date: string; time_slot: string;
  notes: string | null; status: string; created_at: string;
};
type Employee = { id: string; full_name: string };

const GREEN = '#174D36';
const LIME = '#D7F28A';
const BG = '#F5F7F2';

function Button({ title, onPress, secondary = false, disabled = false }: any) {
  return <TouchableOpacity disabled={disabled} onPress={onPress} style={[styles.button, secondary && styles.secondaryButton, disabled && { opacity: 0.5 }]}>
    <Text style={[styles.buttonText, secondary && styles.secondaryButtonText]}>{title}</Text>
  </TouchableOpacity>;
}
function Field({ label, value, onChangeText, placeholder, secureTextEntry = false, keyboardType = 'default', multiline = false }: any) {
  return <View style={{ marginBottom: 13 }}>
    <Text style={styles.label}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder} placeholderTextColor="#89938B"
      secureTextEntry={secureTextEntry} keyboardType={keyboardType} multiline={multiline}
      style={[styles.input, multiline && { minHeight: 76, textAlignVertical: 'top' }]} />
  </View>;
}
function Choice({ label, selected, onPress }: any) {
  return <TouchableOpacity onPress={onPress} style={[styles.choice, selected && styles.choiceSelected]}>
    <Text style={[styles.choiceText, selected && { color: GREEN, fontWeight: '700' }]}>{label}</Text>
  </TouchableOpacity>;
}

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState('Home');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [wasteType, setWasteType] = useState('Dry waste');
  const [frequency, setFrequency] = useState('One-time');
  const [address, setAddress] = useState('');
  const [pickupDate, setPickupDate] = useState(new Date(Date.now() + 86400000).toISOString().slice(0, 10));
  const [timeSlot, setTimeSlot] = useState('9 AM – 11 AM');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session) loadProfile(data.session.user.id);
      else setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession) loadProfile(nextSession.user.id);
      else { setProfile(null); setBookings([]); setLoading(false); }
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function loadProfile(userId: string) {
    const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).single();
    if (error) Alert.alert('Profile error', error.message);
    setProfile(data as Profile | null);
    setLoading(false);
  }

  async function authenticate() {
    if (!email.trim() || password.length < 6) return Alert.alert('Check details', 'Enter your email and a password with at least 6 characters.');
    setBusy(true);
    let result: any;
    if (authMode === 'signup') {
      if (!fullName.trim()) { setBusy(false); return Alert.alert('Name required', 'Please enter your name.'); }
      result = await supabase.auth.signUp({
        email: email.trim().toLowerCase(), password,
        options: { data: { full_name: fullName.trim(), phone: phone.trim() } }
      });
    } else result = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
    setBusy(false);
    if (result.error) Alert.alert('Authentication failed', result.error.message);
    else if (authMode === 'signup' && !result.data.session) Alert.alert('Check your email', 'Confirm your email, then log in.');
  }

  async function refreshBookings() {
    if (!profile) return;
    setBusy(true);
    let query = supabase.from('bookings').select('*').order('created_at', { ascending: false });
    if (profile.role === 'customer') query = query.eq('customer_id', profile.id);
    if (profile.role === 'employee') query = query.eq('assigned_to', profile.id);
    const { data, error } = await query;
    if (error) Alert.alert('Could not load bookings', error.message);
    else setBookings((data || []) as Booking[]);
    if (profile.role === 'admin') {
      const { data: people } = await supabase.from('profiles').select('id,full_name').eq('role', 'employee').order('full_name');
      setEmployees((people || []) as Employee[]);
    }
    setBusy(false);
  }

  useEffect(() => { if (profile) refreshBookings(); }, [profile?.id, profile?.role]);

  async function createBooking() {
    if (!address.trim()) return Alert.alert('Address required', 'Enter the complete pickup address.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(pickupDate)) return Alert.alert('Date format', 'Use YYYY-MM-DD for the pickup date.');
    setBusy(true);
    const { error } = await supabase.from('bookings').insert({
      customer_id: profile!.id, waste_type: wasteType, frequency, address: address.trim(),
      pickup_date: pickupDate, time_slot: timeSlot, notes: notes.trim() || null
    });
    setBusy(false);
    if (error) Alert.alert('Booking failed', error.message);
    else { setAddress(''); setNotes(''); setTab('Bookings'); refreshBookings(); Alert.alert('Booking received', 'Your pickup request has been saved.'); }
  }

  async function updateBooking(id: string, changes: Partial<Booking>) {
    const { error } = await supabase.from('bookings').update(changes).eq('id', id);
    if (error) Alert.alert('Update failed', error.message);
    else refreshBookings();
  }

  async function signOut() { await supabase.auth.signOut(); }

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color={GREEN}/><Text style={styles.muted}>Loading WasteGo…</Text></SafeAreaView>;

  if (!session) return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={GREEN}/>
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.authWrap}>
        <View style={styles.brandMark}><Text style={{ fontSize: 34 }}>♻️</Text></View>
        <Text style={styles.brand}>WasteGo</Text>
        <Text style={styles.tagline}>A cleaner tomorrow, today.</Text>
        <View style={styles.panel}>
          <Text style={styles.heading}>{authMode === 'login' ? 'Welcome back' : 'Create account'}</Text>
          {authMode === 'signup' && <>
            <Field label="Full name" value={fullName} onChangeText={setFullName} placeholder="Your name"/>
            <Field label="Phone (optional)" value={phone} onChangeText={setPhone} placeholder="Mobile number" keyboardType="phone-pad"/>
          </>}
          <Field label="Email" value={email} onChangeText={setEmail} placeholder="you@example.com" keyboardType="email-address"/>
          <Field label="Password" value={password} onChangeText={setPassword} placeholder="At least 6 characters" secureTextEntry/>
          <Button title={busy ? 'Please wait…' : authMode === 'login' ? 'Log in' : 'Create account'} onPress={authenticate} disabled={busy}/>
          <TouchableOpacity onPress={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')} style={{ padding: 14 }}>
            <Text style={styles.link}>{authMode === 'login' ? 'New to WasteGo? Create an account' : 'Already registered? Log in'}</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.smallNote}>Demo development build · Real cloud login when configured</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  </SafeAreaView>;

  if (!profile) return <SafeAreaView style={styles.center}><Text style={styles.heading}>Setting up your profile…</Text><Button title="Reload" onPress={() => loadProfile(session.user.id)}/><Button title="Log out" secondary onPress={signOut}/></SafeAreaView>;

  const isCustomer = profile.role === 'customer';
  const tabs = isCustomer ? ['Home', 'Bookings', 'Account'] : profile.role === 'admin' ? ['Overview', 'Orders', 'Account'] : ['My pickups', 'Account'];

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="light-content" backgroundColor={GREEN}/>
    <View style={styles.header}>
      <View><Text style={styles.headerBrand}>♻️ WasteGo</Text><Text style={styles.headerSub}>{profile.role.toUpperCase()} PORTAL</Text></View>
      <View style={styles.avatar}><Text style={{ color: GREEN, fontWeight: '800' }}>{(profile.full_name || 'W').slice(0,1).toUpperCase()}</Text></View>
    </View>
    <ScrollView contentContainerStyle={styles.content}>
      {isCustomer && tab === 'Home' && <>
        <Text style={styles.eyebrow}>HELLO, {profile.full_name.toUpperCase()}</Text>
        <Text style={styles.title}>A cleaner home{'\n'}starts here.</Text>
        <Text style={styles.muted}>Book a doorstep waste pickup in a few simple steps.</Text>
        <View style={styles.panel}>
          <Text style={styles.heading}>What should we collect?</Text>
          <View style={styles.wrap}>{['Wet waste', 'Dry waste', 'Mixed waste', 'Bulk waste'].map(x => <Choice key={x} label={x} selected={wasteType === x} onPress={() => setWasteType(x)}/>)}</View>
          <Text style={styles.label}>Collection plan</Text>
          <View style={styles.wrap}>{['One-time', 'Daily', 'Weekly'].map(x => <Choice key={x} label={x} selected={frequency === x} onPress={() => setFrequency(x)}/>)}</View>
          <Field label="Pickup address" value={address} onChangeText={setAddress} placeholder="House no., street, area, city" multiline/>
          <Field label="Pickup date (YYYY-MM-DD)" value={pickupDate} onChangeText={setPickupDate} placeholder="2026-11-15"/>
          <Text style={styles.label}>Preferred time</Text>
          <View style={styles.wrap}>{['9 AM – 11 AM', '12 PM – 2 PM', '4 PM – 6 PM'].map(x => <Choice key={x} label={x} selected={timeSlot === x} onPress={() => setTimeSlot(x)}/>)}</View>
          <Field label="Extra instructions (optional)" value={notes} onChangeText={setNotes} placeholder="Gate, landmark, special instructions" multiline/>
          <Button title={busy ? 'Submitting…' : 'Request pickup'} onPress={createBooking} disabled={busy}/>
          <Text style={styles.smallNote}>Booking is a request. Collection timing and service availability must be confirmed by your operator.</Text>
        </View>
      </>}
      {isCustomer && tab === 'Bookings' && <><Text style={styles.title}>My bookings</Text><Button title="Refresh bookings" secondary onPress={refreshBookings}/><BookingList bookings={bookings} role={profile.role}/></>}
      {profile.role === 'admin' && tab === 'Overview' && <>
        <Text style={styles.title}>Business overview</Text>
        <View style={styles.stats}><Stat label="Total orders" value={bookings.length}/><Stat label="Pending" value={bookings.filter(b => b.status === 'pending').length}/></View>
        <Text style={styles.muted}>Use Orders to assign pickups and update collection status.</Text>
        <Button title="View orders" onPress={() => setTab('Orders')}/>
      </>}
      {profile.role === 'admin' && tab === 'Orders' && <>
        <Text style={styles.title}>All pickup orders</Text><Button title="Refresh orders" secondary onPress={refreshBookings}/>
        {bookings.map(b => <View key={b.id} style={styles.orderCard}>
          <Text style={styles.orderTitle}>{b.waste_type} · {b.status.toUpperCase()}</Text>
          <Text style={styles.orderText}>{b.address}</Text><Text style={styles.orderText}>{b.pickup_date} · {b.time_slot} · {b.frequency}</Text>
          <Text style={styles.smallNote}>Booking ID: {b.id.slice(0,8)}</Text>
          <Text style={styles.label}>Assign employee</Text>
          {employees.map(e => <Choice key={e.id} label={e.full_name} selected={b.assigned_to === e.id} onPress={() => updateBooking(b.id, { assigned_to: e.id, status: 'assigned' })}/>)}
          <View style={styles.wrap}>
            {['pending','assigned','collected'].map(s => <Choice key={s} label={s} selected={b.status === s} onPress={() => updateBooking(b.id, { status: s })}/>)}
          </View>
        </View>)}
        {bookings.length === 0 && <Text style={styles.muted}>No orders yet.</Text>}
      </>}
      {profile.role === 'employee' && tab === 'My pickups' && <>
        <Text style={styles.title}>Assigned pickups</Text><Button title="Refresh tasks" secondary onPress={refreshBookings}/>
        {bookings.map(b => <View key={b.id} style={styles.orderCard}>
          <Text style={styles.orderTitle}>{b.waste_type}</Text><Text style={styles.orderText}>{b.address}</Text>
          <Text style={styles.orderText}>{b.pickup_date} · {b.time_slot}</Text>
          <Text style={styles.label}>Update status</Text>
          <View style={styles.wrap}>{['assigned','collected'].map(s => <Choice key={s} label={s} selected={b.status === s} onPress={() => updateBooking(b.id, { status: s })}/>)}</View>
        </View>)}
        {bookings.length === 0 && <Text style={styles.muted}>No pickups assigned to you yet.</Text>}
      </>}
      {tab === 'Account' && <>
        <Text style={styles.title}>Your account</Text>
        <View style={styles.panel}><Text style={styles.heading}>{profile.full_name}</Text><Text style={styles.muted}>{session.user.email}</Text><Text style={styles.muted}>Role: {profile.role}</Text><Text style={styles.muted}>Phone: {profile.phone || 'Not added'}</Text></View>
        <Button title="Log out" secondary onPress={signOut}/>
      </>}
    </ScrollView>
    <View style={styles.nav}>{tabs.map(t => <TouchableOpacity key={t} onPress={() => { setTab(t); if (t === 'Bookings' || t === 'Orders' || t === 'My pickups') refreshBookings(); }} style={styles.navItem}>
      <Text style={[styles.navText, tab === t && styles.navActive]}>{t}</Text>
    </TouchableOpacity>)}</View>
  </SafeAreaView>;
}

function BookingList({ bookings, role }: { bookings: Booking[]; role: string }) {
  if (!bookings.length) return <View style={styles.empty}><Text style={{ fontSize: 36 }}>🧺</Text><Text style={styles.heading}>No pickups yet</Text><Text style={styles.muted}>Your collection requests will appear here.</Text></View>;
  return <>{bookings.map(b => <View key={b.id} style={styles.orderCard}>
    <Text style={styles.orderTitle}>{b.waste_type}</Text><Text style={styles.orderText}>{b.address}</Text>
    <Text style={styles.orderText}>{b.pickup_date} · {b.time_slot}</Text>
    <Text style={styles.orderText}>{b.frequency}</Text><Text style={styles.status}>{b.status.toUpperCase()}</Text>
  </View>)}</>;
}
function Stat({ label, value }: any) { return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.muted}>{label}</Text></View>; }

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: BG }, center: { flex: 1, backgroundColor: BG, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 20 },
  authWrap: { flexGrow: 1, justifyContent: 'center', padding: 24, backgroundColor: GREEN },
  brandMark: { alignSelf: 'center', backgroundColor: LIME, width: 74, height: 74, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  brand: { color: 'white', fontSize: 34, fontWeight: '900', textAlign: 'center' }, tagline: { color: '#DDEBD9', textAlign: 'center', marginBottom: 26 },
  panel: { backgroundColor: 'white', borderRadius: 20, padding: 18, marginTop: 18, marginBottom: 16 },
  heading: { fontSize: 21, color: GREEN, fontWeight: '800', marginBottom: 14 }, label: { color: GREEN, fontWeight: '700', marginBottom: 7, marginTop: 5 },
  input: { backgroundColor: '#F4F6F2', borderWidth: 1, borderColor: '#DCE4D8', borderRadius: 12, padding: 13, color: '#18251D', fontSize: 15 },
  button: { backgroundColor: GREEN, borderRadius: 13, padding: 15, alignItems: 'center', marginTop: 8 },
  buttonText: { color: 'white', fontWeight: '800', fontSize: 15 }, secondaryButton: { backgroundColor: '#E8EFE5' }, secondaryButtonText: { color: GREEN },
  link: { textAlign: 'center', color: GREEN, fontWeight: '700' }, smallNote: { color: '#77837A', fontSize: 11, marginTop: 9, lineHeight: 16 },
  muted: { color: '#69766D', fontSize: 14, lineHeight: 20 }, header: { backgroundColor: GREEN, padding: 18, paddingTop: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerBrand: { color: 'white', fontSize: 23, fontWeight: '900' }, headerSub: { color: '#D7F28A', fontSize: 10, fontWeight: '800', letterSpacing: 1.5, marginTop: 3 },
  avatar: { width: 42, height: 42, borderRadius: 21, backgroundColor: LIME, alignItems: 'center', justifyContent: 'center' },
  content: { padding: 18, paddingBottom: 28 }, eyebrow: { color: '#5C8A63', fontSize: 11, fontWeight: '900', letterSpacing: 1.4, marginTop: 8 },
  title: { color: GREEN, fontSize: 29, fontWeight: '900', marginTop: 8, marginBottom: 8 }, wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  choice: { borderWidth: 1, borderColor: '#D7E0D5', backgroundColor: '#F7F9F5', borderRadius: 11, paddingVertical: 10, paddingHorizontal: 12, marginBottom: 5 },
  choiceSelected: { borderColor: GREEN, backgroundColor: '#E9F2E4' }, choiceText: { color: '#536157', fontSize: 13 },
  nav: { flexDirection: 'row', backgroundColor: 'white', borderTopWidth: 1, borderTopColor: '#E4EAE1', paddingVertical: 12, justifyContent: 'space-around' },
  navItem: { padding: 5 }, navText: { color: '#89948B', fontSize: 12, fontWeight: '700' }, navActive: { color: GREEN },
  orderCard: { backgroundColor: 'white', borderRadius: 16, padding: 16, marginTop: 12, borderWidth: 1, borderColor: '#E4EAE1' },
  orderTitle: { color: GREEN, fontSize: 17, fontWeight: '800', marginBottom: 6 }, orderText: { color: '#536157', fontSize: 13, marginBottom: 4 },
  status: { color: GREEN, fontWeight: '900', marginTop: 8, fontSize: 11 }, empty: { alignItems: 'center', padding: 28, backgroundColor: 'white', borderRadius: 16, marginTop: 18 },
  stats: { flexDirection: 'row', gap: 12, marginVertical: 16 }, stat: { flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 18 },
  statValue: { color: GREEN, fontSize: 30, fontWeight: '900' }
});